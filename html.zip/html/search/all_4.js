var searchData=
[
  ['mainwindow_0',['MainWindow',['../classMainWindow.html',1,'MainWindow'],['../classMainWindow.html#a8b244be8b7b7db1b08de2a2acb9409db',1,'MainWindow::MainWindow()']]],
  ['mainwindow_2eh_1',['mainwindow.h',['../mainwindow_8h.html',1,'']]]
];
